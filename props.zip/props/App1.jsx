import React, { Component } from 'react';
import App2 from './App2';

export default class App1 extends Component {
  render() {
    return (
      <>
      <App2 data="harish" name="gowda" />
      </>
    )
  }
}
