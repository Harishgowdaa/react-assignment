import React from 'react';
import Q1 from './Q1';

const P1 = () => {
    return (
        <Q1 data="Hii" name="Idiot" />
    );
}
export default P1;
